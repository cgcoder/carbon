import { v4 as uuidv4 } from 'uuid';

export function generateId(prefix: string): string {
  return `${prefix}_${uuidv4().replace(/-/g, '').substring(0, 12)}`;
}
