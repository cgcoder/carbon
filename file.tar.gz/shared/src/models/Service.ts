export interface Service {
  /** Immutable identifier used as the directory name. Cannot be changed after creation. */
  name: string;
  /** Human-readable label shown in the UI. Can be updated freely. */
  displayName: string;
  description?: string;
  /** Hostname this service is associated with (e.g. "api.example.com"). */
  hostname?: string;
  /** When true, incoming requests must carry a Host header matching `hostname` to be routed to this service. */
  matchHostName?: boolean;
  injectLatencyMs?: number;
  /** Optional URL prefix. If set, incoming requests must start with this prefix for this service to be considered. API urlPattern is then matched against the path with the prefix stripped. */
  urlPrefix?: string;
  /** When false the service is completely ignored by the mock router. Defaults to true when absent. */
  enabled?: boolean;
}
